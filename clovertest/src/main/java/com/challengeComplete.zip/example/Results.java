package com.example;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by joe-work on 3/15/15.
 */
public class Results {

    public List<Result> results = new ArrayList<Result>();
}
