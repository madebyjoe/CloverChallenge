package com.example;

import java.util.List;

/**
 * Created by joe-work on 3/15/15.
 */
public class Profile {

    public int id;
    public List<QuestionResponse> answers;
}
